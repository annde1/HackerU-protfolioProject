# Brain Busters Quiz Game

Brain Busters Quiz Game is an interactive quiz game that tests your knowledge on a variety of topics. Challenge yourself with a series of questions, each with a limited time to answer, and see how many you can answer correctly!

## Table of Contents

- [Features](#features)
- [Getting Started](#getting-started)
- [Gameplay](#gameplay)
- [Customization](#customization)
- [Technical Details](#technical-details)

## Features

- **Dynamic Quizzes:** The game fetches questions from an external API to provide a diverse range of questions.
- **Player Name:** Start the game by entering your player name.
- **Number of Questions:** Choose the number of questions you want to answer in each quiz.
- **Time Limit:** Set a time limit for each question to add an extra challenge.
- **Real-time Timer:** A timer counts down the remaining time for each question.
- **Question Progress:** Track your progress with a question counter.
- **Score Tracking:** Your score is displayed at the end of the quiz.
- **Restart Option:** Start a new quiz or restart the current one.

## Getting Started

To play Brain Busters Quiz Game, follow these steps:

1. **Install a Local Server:** Ensure you have a local server installed. If you don't have one, you can use [Live Server](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer) if you're using Visual Studio Code, or any other local server of your choice.

2. **Clone the Repository:** Clone this repository to your local machine.

3. **Open with a Local Server:** Use your local server to open the `index.html` file. This will start the game in your default web browser.

4. **Enter Player Name:** When the game starts, enter your player name in the provided field.

5. **Configure Quiz Options:** Choose the number of questions and the time limit per question using the dropdown menus.

6. **Start the Quiz:** Click the "Start Quiz" button to begin the quiz.

## Gameplay

- Answer each question by selecting the correct option.
- You have a limited time to answer each question.
- The timer on each question indicates the remaining time.
- After answering, click "Submit" to check your answer.
- Correct answers will be highlighted in green, while incorrect answers will be highlighted in red.
- The score is displayed at the end of the quiz.

## Customization

You can customize your Brain Busters Quiz Game experience in the following ways:

- **Number of Questions:** Choose how many questions you want in each quiz.
- **Time for Question:** Set the time limit for each question.
- **Player Name:** Enter your name to personalize your gaming experience.

## Technical Details

- **HTML, CSS, and JavaScript:** The game is built using these web technologies.
- **Bootstrap:** The Bootstrap framework is used for styling.
- **External API:** Questions are fetched from an external trivia questions API.
- **Module Structure:** The code is organized into separate modules for maintainability.
