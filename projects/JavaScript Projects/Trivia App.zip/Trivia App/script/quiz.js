const startGameScreen = document.querySelector("#start-game-screen");
const questionsScreen = document.querySelector("#question-screen");
const questionLabel = document.querySelector("#question");
const answerContainer = document.querySelector("#answers");
const questionNumber = document.querySelector("#question-number");
const endOfGameScreen = document.querySelector("#game-end");
const category = document.querySelector("#category");

class Quiz {
  constructor(address) {
    this.address = address;
    this.questions = [];
    this.correctAnswer;
    this.currentQuestion = 0;
  }
  async fetchQuestions() {
    try {
      let dataFromServer = await fetch(this.address);
      let questions = await dataFromServer.json();
      startGameScreen.classList.add("hide");
      questionsScreen.classList.remove("hide");
      return questions;
    } catch (err) {
      console.log(err);
    }
  }
  //Return true when the answer is correct or false when the answer is incorrect
  validateAnswer(answer) {
    if (this.questions[this.currentQuestion].correct_answer === answer) {
      return true;
    } else {
      return false;
    }
  }
  //Chcked if player is at the last question
  isLastQuestion() {
    if (this.questions.length - 1 === this.currentQuestion) {
      return true;
    }
    return false;
  }
  //Increment the current question
  nextQuestion() {
    this.currentQuestion++;
  }

  getQuestion() {
    return this.questions[this.currentQuestion];
  }
  //If this method returns 0, means we are at hte end of the quiz
  endQuiz() {
    this.currentQuestion = 0;
  }
  //TODO: function to shuffle answers
}
const renderQuestion = (question, answers, number, length, categoryName) => {
  answerContainer.innerHTML = "";

  category.innerHTML = `${categoryName}`;
  questionNumber.innerHTML = `Question ${number + 1}/${length}`;
  questionLabel.innerHTML = question;
  for (let i = 0; i < answers.length; i++) {
    const html = `<input
                class="form-check-input answerInput"
                type="radio"
                name="answer"
                value=""
                id=input${[i]}
              />
              <label class="form-check-label answer" for="flexCheckDefault${i}">
                ${answers[i]}
              </label>`;
    const div = document.createElement("div");
    div.classList.add("form-check", "option-answer");
    div.innerHTML = html;
    answerContainer.appendChild(div);
  }
};

const showEndGame = (playerScore, maxScore, playersName) => {
  questionsScreen.classList.add("hide");
  endOfGameScreen.classList.remove("hide-section");
  const total = document.querySelector("#the-score");
  total.innerHTML = `${playerScore}/${maxScore}`;
  const message = document.querySelector("#message");
  message.innerHTML = `Well done, ${playersName}`;
};
const showStartScreen = () => {
  endOfGameScreen.classList.add("hide-section");
  startGameScreen.classList.remove("hide");
};

export { renderQuestion };
export { Quiz };
export { showEndGame };
export { showStartScreen };
