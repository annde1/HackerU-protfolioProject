class Player {
  constructor(name) {
    this.playerName = name;
    this.score = 0;
  }
  setScore() {
    let obj = {
      playersName: this.playerName,
      score: this.score,
    };
    const jsonStr = JSON.stringify(obj);
    localStorage.setItem(`Trivia${this.playerName}`, jsonStr);
  }
  get;
}
export { Player };
