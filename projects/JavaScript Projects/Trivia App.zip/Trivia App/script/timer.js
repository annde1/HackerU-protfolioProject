class Timer {
  constructor(duration, element, timeoutHandler) {
    this.timerDuration = duration;
    this.currentTime = duration;
    this.timerElement = document.getElementById(element);
    this.interval;
    this.outOfTime = false;
    this.timeoutHandler = timeoutHandler;
  }
  //TODO: A mtehod to start Timer:
  startTimer() {
    this.updateTimerDisplay();
    this.interval = setInterval(() => {
      this.updateTimer();
      if (this.currentTime < 0) {
        this.outOfTime = true;
        this.stopTimer();
        this.timeoutHandler();
      } else {
        this.updateTimerDisplay();
      }
    }, 1000);
  }
  //TODO: A method to clear interval?
  stopTimer() {
    clearInterval(this.interval);
  }
  //TODO: a method to decrease time??
  updateTimer() {
    this.currentTime--;
  }
  updateTimerDisplay() {
    const percent = (this.currentTime / this.timerDuration) * 100;
    this.timerElement.style.width = `${percent}%`;
  }
}

export { Timer };
