import { Quiz } from "./quiz.js";
import { Player } from "./player.js";
import { Timer } from "./timer.js";
import { renderQuestion } from "./quiz.js";
import { showEndGame } from "./quiz.js";
import { showStartScreen } from "./quiz.js";

//Variables:
const startBtn = document.querySelector("#start-btn");
const nextBtn = document.querySelector("#next-btn");
const submitBtn = document.querySelector("#submit-btn");
const answersContainer = document.querySelector("#answers");
const restartBtn = document.querySelector("#restart-btn");
const form = document.querySelector("#quiz-form");

let quiz;
let player;
let length;
let clicked;
let timer;
let timeForQuestion;
let userAnswer;

// Function to start the quiz
const startQuiz = async () => {
  let result = await quiz.fetchQuestions();
  quiz.questions = result.results;
  length = quiz.questions.length;
  let question = quiz.getQuestion();
  // Render the first question and initialize the timer
  renderQuestion(
    question.question,
    [...question.incorrect_answers, question.correct_answer],
    quiz.currentQuestion,
    quiz.questions.length,
    quiz.questions[quiz.currentQuestion].category
  );
  timer = new Timer(timeForQuestion, "timer", handleButton);
  timer.startTimer();
};
// Function to handle button states
const handleButton = () => {
  const radioButtons = document.querySelectorAll(".answerInput");
  // Disable radio buttons when time is up
  if (timer.outOfTime) {
    radioButtons.forEach((button) => {
      button.disabled = true;
    });
  }
  submitBtn.classList.add("hide-btn");
  nextBtn.classList.remove("hide-btn");
};
window.addEventListener("load", () => {
  // Event listener for starting a new quiz
  startBtn.addEventListener("click", async (e) => {
    e.preventDefault();
    const playerName = document.querySelector("#playerName").value;
    const numOfQuestions = +document.querySelector("#numQuestions").value;
    timeForQuestion = +document.querySelector("#timePerQuestion").value;

    //if there is no player name orno time selected or no time for question don't start the game
    if (!playerName || !numOfQuestions || !timeForQuestion) {
      return;
    }
    //if user selected time etc.. start the quiz.Create a new Quiz and Player objects
    quiz = new Quiz(`https://opentdb.com/api.php?amount=${numOfQuestions}`);
    player = new Player(playerName);
    try {
      await startQuiz();
    } catch (err) {
      console.log(err);
    }
  });
  // Event listener for submitting an answer
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const correctAnswer = quiz.questions[quiz.currentQuestion].correct_answer;
    if (userAnswer === correctAnswer) {
      clicked.classList.add("correct");
    } else if (userAnswer !== correctAnswer) {
      clicked.classList.add("wrong");
    }
    timer.stopTimer();
    submitBtn.classList.add("hide-btn");
    nextBtn.classList.remove("hide-btn");
    const radioButtons = document.querySelectorAll(".answerInput");
    radioButtons.forEach((radio) => {
      radio.disabled = true;
    });
  });
  // Event listener for selecting an answer
  answersContainer.addEventListener("change", (e) => {
    const target = e.target;
    let isChecked;
    if (target.classList.contains("answerInput")) {
      isChecked = target.checked;
      clicked = target.parentElement;
      userAnswer = target.nextElementSibling.innerText;
    }
    //If user answered correctly increase his score
    if (quiz.validateAnswer(userAnswer)) {
      player.score++;
    }

    submitBtn.disabled = !isChecked;
  });
  //When user clicks on next button create new timer
  nextBtn.addEventListener("click", () => {
    timer = new Timer(timeForQuestion, "timer", handleButton);
    timer.startTimer();
    nextBtn.classList.add("hide-btn");

    if (quiz.isLastQuestion()) {
      // End the quiz and show the final score
      quiz.endQuiz();
      timer.stopTimer();
      showEndGame(player.score, quiz.questions.length, player.playerName);
    } else {
      // Move to the next question
      quiz.nextQuestion();
      let question = quiz.getQuestion();
      renderQuestion(
        question.question,
        [...question.incorrect_answers, question.correct_answer],
        quiz.currentQuestion,
        quiz.questions.length,
        quiz.questions[quiz.currentQuestion].category
      );
      submitBtn.classList.remove("hide-btn");
      submitBtn.disabled = true;
    }
    //Increment current question
  });
  // Event listener for the "Restart" button
  restartBtn.addEventListener("click", () => {
    submitBtn.classList.remove("hide-btn");
    submitBtn.disabled = true;
    // Show the start screen to begin a new quiz
    showStartScreen();
  });
});
